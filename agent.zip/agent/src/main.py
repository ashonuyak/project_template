from paho.mqtt import client as mqtt_client
import json
import time
from schema.aggregated_data_schema import AggregatedDataSchema
from domain.accelerometer import Accelerometer
from domain.gps import Gps
from domain.parking import Parking
from file_datasource import FileDatasource
import config


def connect_mqtt(broker, port):
    """Create MQTT client"""
    print(f"CONNECT TO {broker}:{port}")

    def on_connect(client, userdata, flags, rc):
        if rc == 0:
            print(f"Connected to MQTT Broker ({broker}:{port})!")
        else:
            print("Failed to connect {broker}:{port}, return code %d\n", rc)
            exit(rc)  # Stop execution

    client = mqtt_client.Client()
    client.on_connect = on_connect
    client.connect(broker, port)
    client.loop_start()
    return client


def publish(client, topics, datasource, delay):
    datasource.startReading()
    while True:
        time.sleep(delay)
        data = datasource.read()
        if not data:
            print("No more data to read.")
            break

        print(data)

        # Determine the type of data and select the appropriate topic
        if isinstance(data, Accelerometer):
            msg = AggregatedDataSchema().dumps(data)
            topic = topics['accelerometer']
        elif isinstance(data, Gps):
            msg = AggregatedDataSchema().dumps(data)
            topic = topics['gps']
        elif isinstance(data, Parking):
            msg = AggregatedDataSchema().dumps(data)
            topic = topics['parking']
        else:
            print("Unknown data type.")
            continue

        # Publish the message
        result = client.publish(topic, msg)
        status = result[0]
        if status == 0:
            print(f"Sent `{msg}` to topic `{topic}`")
        else:
            print(f"Failed to send message to topic {topic}")


def run():
    # Prepare mqtt client
    client = connect_mqtt(config.MQTT_BROKER_HOST, config.MQTT_BROKER_PORT)
    # Define topics for each type of data
    topics = {
        'accelerometer': 'measurement/accelerometer',
        'gps': 'measurement/gps',
        'parking': 'measurement/parking'
    }
    # Prepare datasource
    datasource = FileDatasource("data/accelerometer.csv", "data/gps.csv", "data/parking.csv")
    # Infinity publish data
    publish(client, topics, datasource, config.DELAY)


if __name__ == "__main__":
    run()
