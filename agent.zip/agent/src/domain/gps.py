from dataclasses import dataclass


@dataclass
class Gps:
    longitude: float
    latitude: float
